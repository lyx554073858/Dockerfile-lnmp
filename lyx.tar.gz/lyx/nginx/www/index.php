<?php



    phpinfo();
